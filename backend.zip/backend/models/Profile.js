import mongoose from "mongoose";

const ProfileSchema =  new mongoose.Schema(
    {
        age : {type:Number,required:true,unique:true},
        dob : {type:String,required:true,unique:true},
        gender : {type:String,required:true,unique:true},
        mobileno : {type:String,required:true,unique:true},
        
    },
    {
        timestamps:true,
    }
);

const  Profile = mongoose.model('Profile',ProfileSchema);

export default Profile;
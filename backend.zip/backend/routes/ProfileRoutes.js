import express from 'express';
import expressAsyncHandler from 'express-async-handler';
import Profile from '../models/Profile.js';
// import bcrypt from 'bcryptjs';
// import { generatetoken } from '../utils.js';
const ProfileRouter = express.Router();

ProfileRouter.post('/create',
    expressAsyncHandler(async(req,res)=>{
        console.log('enterd');
        const AddProfile = new Profile(
            {
                age : req.body.value.age,
                dob:req.body.value.dob,
                gender : req.body.value.gender,
                mobileno:req.body.value.mobileno
            }
        );
        console.log(req)
        const Add = await AddProfile.save();
        res.send({
            age : Add.age,
            dob:Add.dob,
            gender : Add.gender,
            mobileno:Add.mobileno
        });
    })
);
ProfileRouter.post(
    '/signin',
    expressAsyncHandler(async (req,res)=>{
        const profile = await Profile.findOne({ age:req.body.value.age});
        if(profile) {
               // if(req.body.value.password === p.password) {
                    res.send({
                        age : profile.age,
                    });
                    return ;
               // }
        }
        res.status(401).send({message:'Invalid profile!'});
    })
);

export default ProfileRouter;